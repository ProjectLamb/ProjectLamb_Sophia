using UnityEngine;
using UnityEngine.Events;

public class ContinueUIButton : PointerInteractableUIButton
{
    
}
using UnityEngine;
using UnityEngine.Events;

public class NewGameUIButton : PointerInteractableUIButton
{
    
}
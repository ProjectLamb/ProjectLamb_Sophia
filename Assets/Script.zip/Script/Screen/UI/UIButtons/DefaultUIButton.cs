using UnityEngine;

public class DefaultUIButton : PointerInteractableUIButton {
    
}
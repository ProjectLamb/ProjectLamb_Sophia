using UnityEngine;

public class ExitUIButton : PointerInteractableUIButton {
    
}
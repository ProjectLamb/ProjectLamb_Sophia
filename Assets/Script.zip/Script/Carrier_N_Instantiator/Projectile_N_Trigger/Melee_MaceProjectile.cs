using System;
using System.Collections.Generic;
using UnityEngine;
using Sophia_Carriers;

    /// <summary>
    /// Instantiate().Initialize(int amount, Entity owner)를 꼭 설정해야함 <br/>
    /// 초기화가 잘 되었는지 예외처리도 하겠다. 
    /// 프로젝타일은 다~~ 오브젝트 풀 사용하게끔 해보자.
    /// </summary>

namespace Sophia_Carriers
{
    public class Melee_MaceProjectile : Projectile {
//      public      VFXObject       DestroyEffect       = null;
//      public      CARRIER_TYPE    CarrierType;
//      public      BUCKET_POSITION BucketPosition;
//      public      bool            IsInitialized       = false;
//      public      bool            IsActivated         = false;
//      public      bool            IsCloned         = false;
//      protected   Collider        carrierCollider     = null;
//      protected   Rigidbody       carrierRigidBody    = null;

//      [SerializeField] public VFXObject       HitEffect = null;
//      [SerializeField] public ParticleSystem  ProjectileParticle = null;
//      [SerializeField] public int             ProjecttileDamage;
//      [SerializeField] public float           DestroyTime = 0.5f;
//      [SerializeField] public float           ColliderTime = 0.5f;
//      public Entity                           ownerEntity;
//      public List<EntityAffector>             projectileAffector;

    }
}
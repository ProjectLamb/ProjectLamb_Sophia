namespace Sophia
{
    public enum E_MODEL_IDENTIFIRE {
        skins
    }

    public enum E_MODEL_HAND {
        LeftHand, RightHand
    }
}
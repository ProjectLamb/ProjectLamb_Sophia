Atomic Affect는
Affect(버프, 디버프)를 구현하는데 있어서 사용되는 
원자적인 컴포지트(Composite)에 해당한다.
이 다양한 컴포지트를 사용하여 다양한 Affect를 구현한다.

Affect는 컴포넌트 컴포지트 패턴에 영감을 받은 구현체다.